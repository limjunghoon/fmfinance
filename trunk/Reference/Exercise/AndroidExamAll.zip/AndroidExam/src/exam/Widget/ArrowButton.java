package exam.Widget;

import android.app.*;
import android.os.*;
import exam.AndroidExam.*;

public class ArrowButton extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.widget_arrowbutton);
    }
}